"use client";
import { useEffect, useState } from "react";
import { getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function GetInvolved() {
  const [c, setC] = useState({
    headline: "Give Back. Empower. Inspire.",
    body: "",
    button_label: "Become a Volunteer",
    button_url: "#",
    image_url: "",
  });

  useEffect(() => {
    getContent("get_involved", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-8">
      <Reveal>
      <div className="relative rounded-3xl overflow-hidden min-h-[420px] flex items-center bg-brand-ink">
        {c.image_url ? (
          <img src={c.image_url} alt="Volunteers" className="absolute inset-0 w-full h-full object-cover opacity-50" />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-brand-ink to-brand-purpleDark" />
        )}
        <div className="relative z-10 p-8 md:p-16 grid md:grid-cols-2 gap-8 items-center w-full">
          <h2 className="font-heading text-3xl md:text-5xl font-extrabold text-white leading-tight">
            {c.headline}
          </h2>
          <div>
            <p className="text-white/90 leading-relaxed mb-6">{c.body}</p>
            <a
              href={c.button_url}
              className="inline-flex rounded-full bg-brand-purple text-white font-semibold px-7 py-3.5 hover:bg-brand-purpleDark hover:-translate-y-0.5 transition-all"
            >
              {c.button_label}
            </a>
          </div>
        </div>
      </div>
      </Reveal>
    </section>
  );
}
