"use client";
import { useEffect, useState } from "react";
import { getRows, getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function Partners() {
  const [partners, setPartners] = useState([]);
  const [c, setC] = useState({
    headline: "Who We Partner With",
    button_label: "Partner with Us",
    button_url: "/contact-us",
    image_url: "",
  });

  useEffect(() => {
    getRows("partners").then((rows) => setPartners(rows.filter((r) => r.is_visible)));
    getContent("partners_section", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section id="partners" className="py-24 md:py-32 bg-white">
      <div className="max-w-6xl mx-auto px-5 md:px-8 text-center">
        <Reveal>
          <p className="text-brand-purple font-semibold uppercase tracking-wide text-sm mb-3">Our Network</p>
          <h2 className="font-heading text-2xl md:text-4xl font-extrabold text-brand-ink mb-14">
            {c.headline}
          </h2>
        </Reveal>
        <div className="flex flex-wrap justify-center items-center gap-x-14 gap-y-10 mb-16">
          {partners.map((p, i) => (
            <Reveal key={p.id} delay={i * 80}>
              <a
                href={p.link_url}
                className="block w-28 h-16 md:w-32 md:h-20 grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all"
                title={p.name}
              >
                {p.logo_url ? (
                  <img src={p.logo_url} alt={p.name} className="w-full h-full object-contain" />
                ) : (
                  <span className="text-xs text-gray-400 flex items-center justify-center h-full text-center">
                    {p.name}
                  </span>
                )}
              </a>
            </Reveal>
          ))}
        </div>
        <Reveal delay={200}>
          <a
            href={c.button_url}
            className="inline-flex rounded-full bg-brand-ink text-white font-semibold px-7 py-3.5 hover:bg-brand-purple hover:-translate-y-0.5 transition-all"
          >
            {c.button_label}
          </a>
        </Reveal>
      </div>
    </section>
  );
}
