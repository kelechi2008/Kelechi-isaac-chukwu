"use client";
import { useEffect, useState } from "react";
import { getRows, getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function ImpactStories() {
  const [stories, setStories] = useState([]);
  const [headline, setHeadline] = useState("Our Impact Stories");

  useEffect(() => {
    getRows("stories").then((rows) => setStories(rows.filter((r) => r.is_visible)));
    getContent("impact_stories_section", { headline }).then((c) => setHeadline(c.headline));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (stories.length === 0) return null;

  return (
    <section id="impact-stories" className="py-24 md:py-32 bg-brand-cream">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <Reveal>
          <div className="text-center mb-16">
            <p className="text-brand-purple font-semibold uppercase tracking-wide text-sm mb-3">Real Stories</p>
            <h2 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink">
              {headline}
            </h2>
          </div>
        </Reveal>
        <div className="grid md:grid-cols-2 gap-6 md:gap-10">
          {stories.map((s, i) => (
            <Reveal key={s.id} delay={i * 150}>
              <div className="bg-white rounded-3xl p-9 md:p-12 shadow-sm hover:shadow-lg transition-shadow h-full">
                <span className="text-brand-orange text-6xl font-heading leading-none">&ldquo;</span>
                <h3 className="font-heading font-bold text-xl text-brand-ink mt-2 mb-5">
                  {s.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{s.quote}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
