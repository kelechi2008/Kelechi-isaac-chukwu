"use client";
import { useEffect, useState } from "react";
import { getRows, getContent } from "../lib/content";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [links, setLinks] = useState([]);
  const [brand, setBrand] = useState({
    name_line1: "THE",
    name_line2: "ZIPPORAH",
    name_line3: "FOUNDATION",
    tagline: "A Youth Empowerment Initiative",
  });
  const [donateUrl, setDonateUrl] = useState("https://paystack.com/pay/donatezippo");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    (async () => {
      const rows = await getRows("nav_links");
      setLinks(rows.filter((r) => r.is_visible));
      const b = await getContent("brand", brand);
      setBrand(b);
      const donate = await getContent("donate_cta", { button_url: donateUrl });
      setDonateUrl(donate.button_url || donateUrl);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const topLevel = links.filter((l) => !l.parent_label);
  const childrenOf = (label) => links.filter((l) => l.parent_label === label);

  return (
    <header
      className={`sticky top-0 z-50 transition-all ${
        scrolled ? "bg-white/95 backdrop-blur shadow-sm" : "bg-white/80 backdrop-blur"
      }`}
    >
      <div
        className={`max-w-7xl mx-auto px-5 md:px-8 flex items-center justify-between transition-all duration-300 ${
          scrolled ? "h-16" : "h-20"
        }`}
      >
        <a href="/" className="leading-tight">
          <div className="font-heading font-extrabold tracking-tight text-brand-ink">
            <span className="text-xs font-semibold text-brand-purple align-top mr-1">
              {brand.name_line1}
            </span>
            <span className="text-lg md:text-xl">{brand.name_line2}</span>
            <br />
            <span className="text-lg md:text-xl">{brand.name_line3}</span>
          </div>
          <div className="text-[10px] tracking-widest uppercase text-gray-500 mt-0.5">
            {brand.tagline}
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {topLevel.map((link) => {
            const kids = childrenOf(link.label);
            return (
              <div key={link.id} className="relative group">
                <a
                  href={link.url}
                  className="text-sm font-medium text-brand-ink hover:text-brand-purple transition-colors"
                >
                  {link.label}
                </a>
                {kids.length > 0 && (
                  <div className="absolute left-0 top-full pt-3 hidden group-hover:block">
                    <div className="bg-white rounded-xl shadow-lg border border-black/5 py-2 min-w-[190px]">
                      {kids.map((k) => (
                        <a
                          key={k.id}
                          href={k.url}
                          className="block px-4 py-2 text-sm text-brand-ink hover:bg-brand-cream hover:text-brand-purple"
                        >
                          {k.label}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        <div className="hidden lg:block">
          <a
            href={donateUrl}
            className="inline-flex items-center rounded-full bg-brand-purple text-white text-sm font-semibold px-6 py-3 hover:bg-brand-purpleDark transition-colors"
          >
            Give Now
          </a>
        </div>

        <button
          className="lg:hidden p-2"
          aria-label="Toggle menu"
          onClick={() => setMobileOpen((v) => !v)}
        >
          <div className="w-6 h-0.5 bg-brand-ink mb-1.5" />
          <div className="w-6 h-0.5 bg-brand-ink mb-1.5" />
          <div className="w-6 h-0.5 bg-brand-ink" />
        </button>
      </div>

      {mobileOpen && (
        <div className="lg:hidden bg-white border-t border-black/5 px-5 pb-6">
          {topLevel.map((link) => (
            <div key={link.id} className="py-2">
              <a href={link.url} className="block font-medium text-brand-ink py-1">
                {link.label}
              </a>
              {childrenOf(link.label).map((k) => (
                <a
                  key={k.id}
                  href={k.url}
                  className="block pl-4 text-sm text-gray-600 py-1"
                >
                  {k.label}
                </a>
              ))}
            </div>
          ))}
          <a
            href={donateUrl}
            className="mt-3 inline-flex items-center rounded-full bg-brand-purple text-white text-sm font-semibold px-6 py-3"
          >
            Give Now
          </a>
        </div>
      )}
    </header>
  );
}
