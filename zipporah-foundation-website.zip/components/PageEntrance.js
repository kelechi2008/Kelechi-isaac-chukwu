"use client";
import { useEffect, useState } from "react";

export default function PageEntrance() {
  const [phase, setPhase] = useState("flip"); // flip -> settled -> out -> done

  useEffect(() => {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setPhase("done");
      return;
    }
    const t1 = setTimeout(() => setPhase("settled"), 1350); // coin lands, wordmark takes over
    const t2 = setTimeout(() => setPhase("out"), 2200); // whole screen fades
    const t3 = setTimeout(() => setPhase("done"), 2900); // unmount
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  if (phase === "done") return null;

  const settled = phase === "settled" || phase === "out";

  return (
    <div
      className={`fixed inset-0 z-[999] flex items-center justify-center bg-brand-ink transition-opacity duration-700 ${
        phase === "out" ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <div className="text-center">
        <div className="coin-stage relative w-24 h-24 mx-auto mb-6">
          <div
            className={`coin-shadow absolute left-1/2 -translate-x-1/2 bottom-[-14px] w-16 h-3 rounded-full bg-black/50 blur-sm ${
              settled ? "opacity-0" : ""
            }`}
          />
          <div className={`coin ${settled ? "coin-away" : "coin-flip"}`}>
            <div className="coin-face coin-front">
              <span className="font-heading font-extrabold text-white text-3xl">Z</span>
            </div>
            <div className="coin-face coin-back">
              <span className="coin-back-ring" />
            </div>
          </div>
        </div>
        <div
          className={`font-heading text-white text-sm tracking-[0.25em] uppercase transition-all duration-700 ${
            settled ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          }`}
        >
          Zipporah
        </div>
      </div>
    </div>
  );
}

