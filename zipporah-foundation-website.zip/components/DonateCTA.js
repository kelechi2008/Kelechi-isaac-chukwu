"use client";
import { useEffect, useState } from "react";
import { getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function DonateCTA() {
  const [c, setC] = useState({
    headline: "Your Gift Can Change The World",
    subheadline: "",
    body: "",
    button_label: "Donate Here",
    button_url: "https://paystack.com/pay/donatezippo",
    image_url: "",
  });

  useEffect(() => {
    getContent("donate_cta", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="relative py-28 md:py-36 bg-brand-purpleDark overflow-hidden">
      {c.image_url && (
        <img src={c.image_url} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />
      )}
      <div className="relative z-10 max-w-3xl mx-auto px-5 text-center">
        <Reveal>
          <h2 className="font-heading text-4xl md:text-6xl font-extrabold text-white mb-4 tracking-tight">
            {c.headline}
          </h2>
          <div className="w-16 h-px bg-white/50 mx-auto mb-6" />
          <p className="text-white text-lg font-semibold mb-4">{c.subheadline}</p>
          <p className="text-white/85 leading-relaxed mb-10 max-w-xl mx-auto">{c.body}</p>
          <a
            href={c.button_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-white text-brand-ink font-bold px-10 py-4.5 hover:bg-brand-cream hover:-translate-y-0.5 transition-all text-lg shadow-xl"
          >
            {c.button_label}
          </a>
        </Reveal>
      </div>
    </section>
  );
}
