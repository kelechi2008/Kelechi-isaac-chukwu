"use client";
import { useEffect, useState } from "react";
import { getRows } from "../lib/content";
import Reveal from "./Reveal";

export default function RecentUpdates() {
  const [updates, setUpdates] = useState([]);

  useEffect(() => {
    getRows("updates").then((rows) => setUpdates(rows.filter((r) => r.is_visible)));
  }, []);

  if (updates.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28">
      <div className="flex items-center gap-4 mb-10">
        <h2 className="font-heading text-2xl md:text-3xl font-extrabold text-brand-ink">
          Recent Updates
        </h2>
        <div className="flex-1 h-px bg-black/10" />
      </div>
      <div className="grid md:grid-cols-3 gap-6">
        {updates.map((u, i) => (
          <Reveal key={u.id} delay={i * 100}>
          <a
            href={u.link_url}
            className="group rounded-2xl overflow-hidden bg-white border border-black/5 shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="aspect-[16/10] bg-gray-100">
              {u.image_url ? (
                <img
                  src={u.image_url}
                  alt={u.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">
                  [Image to be added]
                </div>
              )}
            </div>
            <div className="p-6">
              <h3 className="font-heading font-bold text-brand-ink mb-2 leading-snug group-hover:text-brand-purple transition-colors">
                {u.title}
              </h3>
              {u.excerpt && <p className="text-sm text-gray-600 mb-3">{u.excerpt}</p>}
              <span className="text-xs text-gray-400">
                {u.published_date
                  ? new Date(u.published_date).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })
                  : ""}
              </span>
            </div>
          </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
