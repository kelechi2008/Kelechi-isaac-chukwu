"use client";
import { useEffect, useState } from "react";
import { getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function WhatWeDo() {
  const [c, setC] = useState({
    eyebrow: "What we do",
    headline: "",
    card1_title: "Our Outreaches",
    card1_body: "",
    card1_label: "See Projects..",
    card1_url: "/our-projects",
    card2_title: "Impact Stories",
    card2_body: "",
    card2_label: "Read More",
    card2_url: "/our-projects#impact-stories",
    card3_title: "Our Partners",
    card3_body: "",
    card3_label: "See Partners..",
    card3_url: "#partners",
  });

  useEffect(() => {
    getContent("what_we_do", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cards = [
    { title: c.card1_title, body: c.card1_body, label: c.card1_label, url: c.card1_url },
    { title: c.card2_title, body: c.card2_body, label: c.card2_label, url: c.card2_url },
    { title: c.card3_title, body: c.card3_body, label: c.card3_label, url: c.card3_url },
  ];

  return (
    <section className="bg-brand-cream py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <Reveal>
          <div className="max-w-2xl mb-16">
            <p className="text-brand-purple font-semibold mb-3 uppercase tracking-wide text-sm">{c.eyebrow}</p>
            <h2 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink leading-tight">
              {c.headline}
            </h2>
          </div>
        </Reveal>
        <div className="grid md:grid-cols-5 gap-6">
          {/* Large feature card */}
          <Reveal className="md:col-span-3">
            <div className="group bg-brand-ink rounded-3xl p-10 md:p-12 h-full flex flex-col justify-between min-h-[280px] hover:-translate-y-1 transition-transform">
              <div>
                <span className="text-white/40 font-heading text-sm">01</span>
                <h3 className="font-heading text-2xl md:text-3xl font-bold text-white mt-3 mb-4">
                  {cards[0].title}
                </h3>
                <p className="text-white/70 leading-relaxed max-w-md">{cards[0].body}</p>
              </div>
              <a
                href={cards[0].url}
                className="inline-flex items-center gap-2 text-white font-semibold mt-8 group-hover:gap-3 transition-all"
              >
                {cards[0].label} <span aria-hidden>→</span>
              </a>
            </div>
          </Reveal>

          {/* Two smaller stacked cards */}
          <div className="md:col-span-2 flex flex-col gap-6">
            {[cards[1], cards[2]].map((card, i) => (
              <Reveal key={i} delay={(i + 1) * 120}>
                <div className="group bg-white rounded-3xl p-8 h-full hover:shadow-lg hover:-translate-y-1 transition-all">
                  <span className="text-brand-purple/30 font-heading text-sm">0{i + 2}</span>
                  <h3 className="font-heading text-xl font-bold text-brand-ink mt-2 mb-3">
                    {card.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4 text-sm">{card.body}</p>
                  <a
                    href={card.url}
                    className="inline-flex items-center gap-2 text-brand-purple font-semibold text-sm group-hover:gap-3 transition-all"
                  >
                    {card.label} <span aria-hidden>→</span>
                  </a>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
