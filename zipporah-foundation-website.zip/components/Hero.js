"use client";
import { useEffect, useState } from "react";
import { getContent } from "../lib/content";

export default function Hero() {
  const [c, setC] = useState({
    eyebrow: "Changing the World, One Teenager at A Time.",
    headline: "Welcome to The Zipporah Foundation",
    primary_button_label: "Learn More",
    primary_button_url: "/who-we-are",
    secondary_button_label: "Give to Support",
    secondary_button_url: "https://paystack.com/pay/donatezippo",
    image_url: "",
  });

  useEffect(() => {
    getContent("hero", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    // sync with PageEntrance's iris wipe (~1.5s) so the headline rises up
    // right as the loader clears, instead of finishing early and just sitting there
    const t = setTimeout(() => setLoaded(true), 1500);
    return () => clearTimeout(t);
  }, []);

  const words = (c.headline || "").split(" ");

  return (
    <section className="relative min-h-[92vh] flex items-end overflow-hidden bg-brand-ink">
      {c.image_url ? (
        <img
          src={c.image_url}
          alt="Zipporah Foundation outreach"
          className={`absolute inset-0 w-full h-full object-cover transition-transform duration-[2500ms] ease-out ${
            loaded ? "scale-100" : "scale-110"
          }`}
        />
      ) : (
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_30%,#5B1F99_0%,#171321_65%)]" />
      )}
      <div className="grain-overlay" />
      <svg
        className="absolute -right-[12%] top-1/2 -translate-y-1/2 w-[780px] h-[780px] pointer-events-none hidden md:block"
        viewBox="0 0 780 780"
        aria-hidden="true"
      >
        <circle cx="390" cy="390" r="180" fill="none" stroke="rgba(255,255,255,0.08)" />
        <circle cx="390" cy="390" r="260" fill="none" stroke="#E8763A" opacity="0.35" className="animate-breathe" />
        <circle cx="390" cy="390" r="340" fill="none" stroke="rgba(255,255,255,0.08)" />
        <circle
          cx="390"
          cy="390"
          r="380"
          fill="none"
          stroke="#E8763A"
          opacity="0.2"
          className="animate-breathe"
          style={{ animationDelay: "2s" }}
        />
      </svg>
      <div className="absolute inset-0 bg-gradient-to-t from-brand-ink via-brand-ink/40 to-transparent" />
      <div className="relative z-10 max-w-7xl mx-auto px-5 md:px-8 pb-16 md:pb-24 pt-40 w-full">
        <p
          className={`text-white/80 text-sm tracking-[0.2em] uppercase font-semibold mb-5 transition-all duration-700 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          {c.eyebrow}
        </p>
        <h1 className="font-heading text-5xl sm:text-6xl md:text-8xl font-extrabold text-white max-w-4xl leading-[0.98] tracking-tight flex flex-wrap gap-x-4">
          {words.map((word, i) => (
            <span key={i} className="line-reveal">
              <span
                style={{ animationDelay: loaded ? `${0.1 + i * 0.06}s` : "0s", animationPlayState: loaded ? "running" : "paused" }}
              >
                {word}
              </span>
            </span>
          ))}
        </h1>
        <div
          className={`flex flex-wrap gap-4 mt-10 transition-all duration-700 delay-300 ${
            loaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <a
            href={c.primary_button_url}
            className="rounded-full bg-white text-brand-ink font-semibold px-8 py-4 hover:bg-brand-cream hover:-translate-y-0.5 hover:shadow-lg transition-all"
          >
            {c.primary_button_label}
          </a>
          <a
            href={c.secondary_button_url}
            className="rounded-full border border-white/40 text-white font-semibold px-8 py-4 hover:bg-white hover:text-brand-ink hover:-translate-y-0.5 transition-all"
          >
            {c.secondary_button_label}
          </a>
        </div>
      </div>
      <div className="absolute bottom-8 right-8 z-10 hidden md:flex flex-col items-center gap-2 text-white/60 text-xs tracking-widest">
        <span className="[writing-mode:vertical-rl]">SCROLL</span>
        <div className="w-px h-10 bg-white/40 animate-pulse" />
      </div>
    </section>
  );
}

