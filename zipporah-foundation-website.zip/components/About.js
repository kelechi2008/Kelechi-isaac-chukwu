"use client";
import { useEffect, useState } from "react";
import { getContent } from "../lib/content";
import Reveal from "./Reveal";

export default function About() {
  const [c, setC] = useState({
    eyebrow: "Transforming the future, one life at a time.",
    headline: "",
    body: "",
    read_more_label: "Read More",
    read_more_url: "/who-we-are",
    founder_label: "View Founder's Profile",
    founder_url: "/iamprincesszee",
    image_url: "",
  });

  useEffect(() => {
    getContent("about", c).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-24 md:py-36 grid md:grid-cols-12 gap-12 items-start">
      <div className="order-2 md:order-1 md:col-span-7">
        <Reveal>
          <span className="font-heading text-7xl md:text-8xl font-extrabold text-brand-purple/10 leading-none block mb-4">
            01
          </span>
        </Reveal>
        <Reveal delay={80}>
          <p className="text-brand-orange font-semibold mb-4 -mt-16 md:-mt-20">{c.eyebrow}</p>
        </Reveal>
        <Reveal delay={140}>
          <h2 className="font-heading text-2xl md:text-4xl font-extrabold text-brand-ink mb-6 leading-snug">
            {c.headline}
          </h2>
        </Reveal>
        <Reveal delay={200}>
          <p className="text-gray-600 leading-relaxed mb-9 whitespace-pre-line max-w-xl">{c.body}</p>
        </Reveal>
        <Reveal delay={260}>
          <div className="flex flex-wrap gap-4">
            <a
              href={c.read_more_url}
              className="rounded-full bg-brand-purple text-white font-semibold px-6 py-3 hover:bg-brand-purpleDark hover:-translate-y-0.5 transition-all"
            >
              {c.read_more_label}
            </a>
            <a
              href={c.founder_url}
              className="rounded-full border border-brand-ink/20 text-brand-ink font-semibold px-6 py-3 hover:bg-brand-ink hover:text-white hover:-translate-y-0.5 transition-all"
            >
              {c.founder_label}
            </a>
          </div>
        </Reveal>
      </div>
      <div className="order-1 md:order-2 md:col-span-5">
        <Reveal delay={100}>
          <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-gray-100 shadow-xl">
            {c.image_url ? (
              <img src={c.image_url} alt="Zipporah Foundation outreach" className="w-full h-full object-cover hover:scale-105 transition-transform duration-700" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm text-center px-6">
                [Image to be added in Admin]
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
