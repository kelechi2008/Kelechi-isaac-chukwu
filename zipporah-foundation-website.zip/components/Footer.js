"use client";
import { useEffect, useState } from "react";
import { getRows, getContent } from "../lib/content";

const ICONS = {
  facebook: "f",
  x: "𝕏",
  instagram: "IG",
  tiktok: "TT",
  linkedin: "in",
};

export default function Footer() {
  const [links, setLinks] = useState([]);
  const [socials, setSocials] = useState([]);
  const [footer, setFooter] = useState({
    copyright: "Copyright © 2026 The Zipporah Foundation",
    powered_by: "Powered by The Zipporah Foundation",
  });

  useEffect(() => {
    (async () => {
      const nav = await getRows("nav_links");
      setLinks(nav.filter((n) => !n.parent_label && n.is_visible));
      const soc = await getRows("social_links");
      setSocials(soc.filter((s) => s.is_visible));
      setFooter(await getContent("footer", footer));
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <footer className="bg-white border-t border-black/5 pt-14 pb-8">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="flex flex-wrap justify-center gap-8 text-sm font-medium text-brand-ink mb-6">
          {links.map((l) => (
            <a key={l.id} href={l.url} className="hover:text-brand-purple">
              {l.label}
            </a>
          ))}
        </div>
        <div className="flex justify-center gap-4 mb-8">
          {socials.map((s) => (
            <a
              key={s.id}
              href={s.url}
              target="_blank"
              rel="noreferrer"
              className="w-9 h-9 rounded-full bg-brand-ink text-white flex items-center justify-center text-xs font-semibold hover:bg-brand-purple transition-colors"
            >
              {ICONS[s.platform?.toLowerCase()] || s.platform?.[0]?.toUpperCase()}
            </a>
          ))}
        </div>
        <div className="flex flex-col md:flex-row items-center justify-between text-xs text-gray-500 gap-2">
          <span>{footer.copyright}</span>
          <span>{footer.powered_by}</span>
        </div>
      </div>
    </footer>
  );
}
