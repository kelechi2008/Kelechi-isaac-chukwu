"use client";
import { useEffect, useRef, useState } from "react";
import { getRows } from "../lib/content";
import Reveal from "./Reveal";

function Counter({ value, suffix }) {
  const [n, setN] = useState(0);
  const ref = useRef(null);
  const target = parseInt(String(value).replace(/\D/g, ""), 10) || 0;

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const duration = 1200;
          const startTime = performance.now();
          const step = (now) => {
            const progress = Math.min((now - startTime) / duration, 1);
            setN(Math.floor(progress * target));
            if (progress < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          obs.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);

  return (
    <span ref={ref}>
      {n}
      {suffix}
    </span>
  );
}

export default function ImpactStats() {
  const [stats, setStats] = useState([]);

  useEffect(() => {
    getRows("stats").then(setStats);
  }, []);

  if (stats.length === 0) return null;

  return (
    <section className="bg-white border-b border-black/5">
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-16 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-black/10">
          {stats.map((s, i) => (
            <Reveal key={s.id} delay={i * 120} className="text-center py-8 sm:py-0">
              <div className="font-heading text-5xl md:text-6xl font-extrabold text-brand-purple tracking-tight">
                <Counter value={s.value} suffix={s.suffix} />
              </div>
              <div className="text-gray-500 mt-2 text-sm uppercase tracking-wide">{s.label}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
