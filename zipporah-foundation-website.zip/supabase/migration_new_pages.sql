-- ============================================================
-- ZIPPORAH FOUNDATION — MIGRATION: new pages + contact rebuild
-- Run this once in the Supabase SQL Editor (after schema.sql has
-- already been run at least once). Safe to re-run — it merges
-- into existing rows instead of wiping them.
-- ============================================================

-- 1) Rebuild "contact" with the new Address / Contact block.
--    Uses jsonb merge (||) so any fields you've already edited in
--    Admin are kept; only the fields below are added/overwritten.
insert into site_content (key, value) values
('contact', '{
  "headline": "We would love to Hear from You",
  "subheadline": "Please write or call us with your questions or comments.",
  "address_label": "Address",
  "address": "Suite 103, Holborn House, Plot 649, Frank Afegbua Crescent, Zone E Extension, Federal Capital Territory, Abuja.",
  "contact_label": "Contact",
  "phones": "+2347077777659, +2347077777905, +2347077777931",
  "emails": "thezipporahproject@gmail.com, info@thezipporahfoundation.org"
}')
on conflict (key) do update set value = site_content.value || excluded.value, updated_at = now();

-- 2) New "Who We Are" page content (fill in mission/vision/values in Admin).
insert into site_content (key, value) values
('who_we_are', '{
  "eyebrow": "Transforming the future, one life at a time.",
  "headline": "We are Transforming Communities by Empowering Teenagers - One Life, One Story, One Future at a Time.",
  "body": "The Zipporah Youth Empowerment Initiative (TZYEI) also known as Zipporah Egenege Foundation is a Non-Governmental Organization. It was founded in an effort to protect vulnerable and disabled teenagers who had their rights neglected, and as a result, have now been subjected to different circumstances such as: domestic violence, natural disasters, unequal industrialization, family disintegration and other problems. Our major strategy is geared towards achieving unprecedented results by getting the teenagers creative working with a total workforce from both internal and external stakeholders who will be mostly teenagers to increase access to the total well-being of the vulnerable.",
  "mission_title": "Our Mission",
  "mission_body": "",
  "vision_title": "Our Vision",
  "vision_body": "",
  "values_title": "Our Values",
  "values_body": "",
  "image_url": "",
  "founder_label": "View Founder''s Profile",
  "founder_url": "/iamprincesszee"
}')
on conflict (key) do update set value = site_content.value || excluded.value, updated_at = now();

-- 3) New "Founder" profile page content — fill in via Admin.
insert into site_content (key, value) values
('founder', '{
  "eyebrow": "Meet the Founder",
  "name": "",
  "role": "Founder, The Zipporah Foundation",
  "photo_url": "",
  "quote": "",
  "bio": "",
  "social_label": "",
  "social_url": ""
}')
on conflict (key) do update set value = site_content.value || excluded.value, updated_at = now();

-- 4) Add the new "intro_body" field to the existing What We Do content
--    (keeps your existing card text untouched).
insert into site_content (key, value) values
('what_we_do', '{ "intro_body": "" }')
on conflict (key) do update set value = site_content.value || excluded.value, updated_at = now();

-- 5) Make sure the nav links for the new pages exist (only inserts
--    ones that are missing, so it won't create duplicates).
insert into nav_links (label, url, parent_label, sort_order)
select 'Who We Are', '/who-we-are', 'About', 0
where not exists (select 1 from nav_links where label = 'Who We Are');

insert into nav_links (label, url, parent_label, sort_order)
select 'What We Do', '/what-we-do', 'About', 1
where not exists (select 1 from nav_links where label = 'What We Do');

insert into nav_links (label, url, parent_label, sort_order)
select 'Founder', '/iamprincesszee', 'About', 2
where not exists (select 1 from nav_links where label = 'Founder');
