-- ============================================================
-- ZIPPORAH FOUNDATION — SUPABASE SCHEMA
-- Run this whole file once in Supabase SQL Editor.
-- ============================================================

-- 1) SINGLETON SECTION CONTENT (hero text, about text, donate copy, etc.)
create table if not exists site_content (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);

-- 2) REPEATABLE COLLECTIONS ------------------------------------------------

create table if not exists nav_links (
  id uuid primary key default gen_random_uuid(),
  label text not null,
  url text not null default '#',
  parent_label text, -- if set, this link is a dropdown item under that parent
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists stats (
  id uuid primary key default gen_random_uuid(),
  label text not null,
  value text not null,
  suffix text default '+',
  sort_order int not null default 0
);

create table if not exists stories (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  quote text not null,
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  image_url text,
  link_url text default '#',
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists updates (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  excerpt text,
  image_url text,
  link_url text default '#',
  published_date date default now(),
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists partners (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  logo_url text,
  link_url text default '#',
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists social_links (
  id uuid primary key default gen_random_uuid(),
  platform text not null,
  url text not null,
  sort_order int not null default 0,
  is_visible boolean not null default true
);

create table if not exists contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  phone text,
  message text not null,
  created_at timestamptz default now(),
  is_read boolean not null default false
);

-- ============================================================
-- ROW LEVEL SECURITY
-- Public (anon) can READ everything except contact_messages.
-- Only logged-in admin (authenticated) can WRITE.
-- ============================================================

alter table site_content enable row level security;
alter table nav_links enable row level security;
alter table stats enable row level security;
alter table stories enable row level security;
alter table projects enable row level security;
alter table updates enable row level security;
alter table partners enable row level security;
alter table social_links enable row level security;
alter table contact_messages enable row level security;

-- Public read policies
create policy "public read site_content" on site_content for select using (true);
create policy "public read nav_links" on nav_links for select using (true);
create policy "public read stats" on stats for select using (true);
create policy "public read stories" on stories for select using (true);
create policy "public read projects" on projects for select using (true);
create policy "public read updates" on updates for select using (true);
create policy "public read partners" on partners for select using (true);
create policy "public read social_links" on social_links for select using (true);

-- Anyone can submit the contact form (insert only, cannot read others' messages)
create policy "public insert contact_messages" on contact_messages for insert with check (true);

-- Authenticated (admin) full access
create policy "admin write site_content" on site_content for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write nav_links" on nav_links for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write stats" on stats for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write stories" on stories for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write projects" on projects for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write updates" on updates for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write partners" on partners for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin write social_links" on social_links for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
create policy "admin read contact_messages" on contact_messages for select using (auth.role() = 'authenticated');
create policy "admin update contact_messages" on contact_messages for update using (auth.role() = 'authenticated');
create policy "admin delete contact_messages" on contact_messages for delete using (auth.role() = 'authenticated');

-- Storage bucket for images (logo-free, so this is for photos/partner logos)
insert into storage.buckets (id, name, public) values ('zipporah-media', 'zipporah-media', true)
on conflict (id) do nothing;

create policy "public read media" on storage.objects for select using (bucket_id = 'zipporah-media');
create policy "admin upload media" on storage.objects for insert with check (bucket_id = 'zipporah-media' and auth.role() = 'authenticated');
create policy "admin update media" on storage.objects for update using (bucket_id = 'zipporah-media' and auth.role() = 'authenticated');
create policy "admin delete media" on storage.objects for delete using (bucket_id = 'zipporah-media' and auth.role() = 'authenticated');

-- ============================================================
-- SEED DATA — real content taken from the live site, nothing invented
-- ============================================================

insert into site_content (key, value) values
('brand', '{
  "name_line1": "THE",
  "name_line2": "ZIPPORAH",
  "name_line3": "FOUNDATION",
  "tagline": "A Youth Empowerment Initiative"
}'),
('hero', '{
  "eyebrow": "Changing the World, One Teenager at A Time.",
  "headline": "Welcome to The Zipporah Foundation",
  "primary_button_label": "Learn More",
  "primary_button_url": "/who-we-are",
  "secondary_button_label": "Give to Support",
  "secondary_button_url": "https://paystack.com/pay/donatezippo",
  "image_url": ""
}'),
('about', '{
  "eyebrow": "Transforming the future, one life at a time.",
  "headline": "We are Transforming Communities by Empowering Teenagers - One Life, One Story, One Future at a Time.",
  "body": "The Zipporah Youth Empowerment Initiative (TZYEI) also known as Zipporah Egenege Foundation is a Non-Governmental Organization. It was founded in an effort to protect vulnerable and disabled teenagers who had their rights neglected, and as a result, have now been subjected to different circumstances such as: domestic violence, natural disasters, unequal industrialization, family disintegration and other problems. Our major strategy is geared towards achieving unprecedented results by getting the teenagers creative working with a total workforce from both internal and external stakeholders who will be mostly teenagers to increase access to the total well-being of the vulnerable.",
  "read_more_label": "Read More",
  "read_more_url": "/who-we-are",
  "founder_label": "View Founder''s Profile",
  "founder_url": "/iamprincesszee",
  "image_url": ""
}'),
('what_we_do', '{
  "eyebrow": "What we do",
  "intro_body": "",
  "headline": "Through outreaches, workshops, and community partnerships, we''re breaking cycles of poverty and creating pathways to success.",
  "card1_title": "Our Outreaches",
  "card1_body": "See how we''re showing up for vulnerable teenagers across Nigeria with love, learning, and lasting support.",
  "card1_label": "See Projects..",
  "card1_url": "/our-projects",
  "card2_title": "Impact Stories",
  "card2_body": "Discover powerful stories of change from the teenagers and youth we''ve empowered through our programs.",
  "card2_label": "Read More",
  "card2_url": "/our-projects#impact-stories",
  "card3_title": "Our Partners",
  "card3_body": "Stronger together. Meet the individuals, organizations, and allies helping us build brighter futures for the next generation.",
  "card3_label": "See Partners..",
  "card3_url": "#partners"
}'),
('get_involved', '{
  "headline": "Give Back. Empower. Inspire.",
  "body": "Volunteering with The Zipporah Foundation is more than service – it''s a mission. Be part of a community that''s changing lives through compassion, education, and empowerment.",
  "button_label": "Become a Volunteer",
  "button_url": "https://docs.google.com/forms/d/e/1FAIpQLSdH4DxfLHqKFgB5RqROmy3NSuikCm3c6-jpl7At9D1aBVNtPw/viewform?usp=header",
  "image_url": ""
}'),
('impact_stories_section', '{
  "headline": "Our Impact Stories"
}'),
('partners_section', '{
  "headline": "Who We Partner With",
  "button_label": "Partner with Us",
  "button_url": "/contact-us",
  "image_url": ""
}'),
('donate_cta', '{
  "headline": "Your Gift Can Change The World",
  "subheadline": "Support us and change the course of a teenager''s life, today!",
  "body": "Every donation you make is a step towards creating a world of possibilities for indigent, physically challenged, and vulnerable teenagers in underserved communities. Together, we can shine the light of hope for them to soar.",
  "button_label": "Donate Here",
  "button_url": "https://paystack.com/pay/donatezippo",
  "image_url": ""
}'),
('contact', '{
  "headline": "We would love to Hear from You",
  "subheadline": "Please write or call us with your questions or comments.",
  "address_label": "Address",
  "address": "Suite 103, Holborn House, Plot 649, Frank Afegbua Crescent, Zone E Extension, Federal Capital Territory, Abuja.",
  "contact_label": "Contact",
  "phones": "+2347077777659, +2347077777905, +2347077777931",
  "emails": "thezipporahproject@gmail.com, info@thezipporahfoundation.org"
}'),
('who_we_are', '{
  "eyebrow": "Transforming the future, one life at a time.",
  "headline": "We are Transforming Communities by Empowering Teenagers - One Life, One Story, One Future at a Time.",
  "body": "The Zipporah Youth Empowerment Initiative (TZYEI) also known as Zipporah Egenege Foundation is a Non-Governmental Organization. It was founded in an effort to protect vulnerable and disabled teenagers who had their rights neglected, and as a result, have now been subjected to different circumstances such as: domestic violence, natural disasters, unequal industrialization, family disintegration and other problems. Our major strategy is geared towards achieving unprecedented results by getting the teenagers creative working with a total workforce from both internal and external stakeholders who will be mostly teenagers to increase access to the total well-being of the vulnerable.",
  "mission_title": "Our Mission",
  "mission_body": "",
  "vision_title": "Our Vision",
  "vision_body": "",
  "values_title": "Our Values",
  "values_body": "",
  "image_url": "",
  "founder_label": "View Founder''s Profile",
  "founder_url": "/iamprincesszee"
}'),
('founder', '{
  "eyebrow": "Meet the Founder",
  "name": "",
  "role": "Founder, The Zipporah Foundation",
  "photo_url": "",
  "quote": "",
  "bio": "",
  "social_label": "",
  "social_url": ""
}'),
('footer', '{
  "copyright": "Copyright © 2026 The Zipporah Foundation",
  "powered_by": "Powered by The Zipporah Foundation"
}')
on conflict (key) do nothing;

insert into nav_links (label, url, parent_label, sort_order) values
('Home', '/', null, 0),
('About', '#', null, 1),
('Who We Are', '/who-we-are', 'About', 0),
('What We Do', '/what-we-do', 'About', 1),
('Founder', '/iamprincesszee', 'About', 2),
('Our Projects', '/our-projects', null, 2),
('Impact Stories', '/our-projects#impact-stories', 'Our Projects', 0),
('Contact Us', '/contact-us', null, 3)
on conflict do nothing;

insert into stats (label, value, suffix, sort_order) values
('Teenagers Impacted', '987', '+', 0),
('Empowered', '70', '+', 1),
('Communities', '10', '+', 2)
on conflict do nothing;

insert into stories (title, quote, sort_order) values
('Amina may be blind, but she is not disabled.', 'I never thought I could do something meaningful with my life because of my condition. But through the Skill-Up Programme, I learned tailoring and gained confidence I never knew I had. Today, I run a small business sewing clothes, and people in my community respect and support me. I am forever grateful for this life-changing opportunity.', 0),
('A Brighter Future — for David Pam', 'My family and I struggled to get by, and I had to drop out of school. The support I received through the outreach, including food supplies and school materials, gave me a fresh start. With the encouragement and resources provided, I''m now back in school and determined to build a better future for myself and my family.', 1)
on conflict do nothing;

insert into updates (title, excerpt, link_url, published_date, sort_order) values
('over 16,000 items distributed in obiaruku local government area', '', '/over-16000-items-distributed-in-obiaruku-local-government-area', '2026-05-21', 0),
('Empowering Families at the Easter Community Outreach, Dawaki.', '', '/empowering-families-at-the-easter-community-outreach-dawaki', '2025-04-22', 1),
('The Dawaki/Dutse Community Easter Outreach 2025', '', '/the-dawaki-dutse-community-easter-outreach-2025', '2025-04-10', 2)
on conflict do nothing;

insert into partners (name, link_url, sort_order) values
('Bemmore Oil and Gas', '#', 0),
('American University of Nigeria', '#', 1),
('LMAM', '#', 2),
('The Innercity Mission', '#', 3),
('The Amarak Project', '#', 4)
on conflict do nothing;

insert into social_links (platform, url, sort_order) values
('facebook', 'https://www.facebook.com/share/15HgT5TJx2/?mibextid=wwXIfr', 0),
('x', 'https://x.com/thezipporah_ngo?s=11', 1),
('instagram', 'https://www.instagram.com/the_zipporahfoundation', 2),
('tiktok', 'https://www.tiktok.com/@thezipporahfoundation?_t=ZM-8vkl34dd58x&_r=1', 3)
on conflict do nothing;
