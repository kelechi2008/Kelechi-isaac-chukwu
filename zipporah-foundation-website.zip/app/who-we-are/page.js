"use client";
import { useEffect, useState } from "react";
import { getContent } from "../../lib/content";
import Reveal from "../../components/Reveal";
import DonateCTA from "../../components/DonateCTA";

const DEFAULTS = {
  eyebrow: "Transforming the future, one life at a time.",
  headline:
    "We are Transforming Communities by Empowering Teenagers — One Life, One Story, One Future at a Time.",
  body: "The Zipporah Youth Empowerment Initiative (TZYEI) also known as Zipporah Egenege Foundation is a Non-Governmental Organization. It was founded in an effort to protect vulnerable and disabled teenagers who had their rights neglected, and as a result, have now been subjected to different circumstances such as: domestic violence, natural disasters, unequal industrialization, family disintegration and other problems. Our major strategy is geared towards achieving unprecedented results by getting the teenagers creative working with a total workforce from both internal and external stakeholders who will be mostly teenagers to increase access to the total well-being of the vulnerable.",
  mission_title: "Our Mission",
  mission_body: "",
  vision_title: "Our Vision",
  vision_body: "",
  values_title: "Our Values",
  values_body: "",
  image_url: "",
  founder_label: "View Founder's Profile",
  founder_url: "/iamprincesszee",
};

export default function WhoWeArePage() {
  const [c, setC] = useState(DEFAULTS);

  useEffect(() => {
    getContent("who_we_are", DEFAULTS).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28 grid md:grid-cols-12 gap-12 items-start">
        <div className="md:col-span-7">
          <Reveal>
            <p className="text-brand-orange font-semibold mb-4">{c.eyebrow}</p>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink mb-6 leading-tight">
              {c.headline}
            </h1>
          </Reveal>
          <Reveal delay={140}>
            <p className="text-gray-600 leading-relaxed whitespace-pre-line max-w-2xl mb-6">
              {c.body}
            </p>
          </Reveal>
          <Reveal delay={200}>
            <a
              href={c.founder_url}
              className="inline-flex items-center rounded-full border border-brand-ink/20 text-brand-ink font-semibold px-6 py-3 hover:bg-brand-ink hover:text-white hover:-translate-y-0.5 transition-all"
            >
              {c.founder_label}
            </a>
          </Reveal>
        </div>
        <div className="md:col-span-5">
          <Reveal delay={100}>
            <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-gray-100 shadow-xl">
              {c.image_url ? (
                <img
                  src={c.image_url}
                  alt="The Zipporah Foundation"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm text-center px-6">
                  [Image to be added in Admin]
                </div>
              )}
            </div>
          </Reveal>
        </div>
      </section>

      {(c.mission_body || c.vision_body || c.values_body) && (
        <section className="bg-brand-cream py-20 md:py-28">
          <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-3 gap-8">
            {c.mission_body && (
              <Reveal>
                <div className="bg-white rounded-3xl p-8 h-full shadow-sm">
                  <h2 className="font-heading text-xl font-bold text-brand-ink mb-3">
                    {c.mission_title}
                  </h2>
                  <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                    {c.mission_body}
                  </p>
                </div>
              </Reveal>
            )}
            {c.vision_body && (
              <Reveal delay={100}>
                <div className="bg-white rounded-3xl p-8 h-full shadow-sm">
                  <h2 className="font-heading text-xl font-bold text-brand-ink mb-3">
                    {c.vision_title}
                  </h2>
                  <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                    {c.vision_body}
                  </p>
                </div>
              </Reveal>
            )}
            {c.values_body && (
              <Reveal delay={200}>
                <div className="bg-white rounded-3xl p-8 h-full shadow-sm">
                  <h2 className="font-heading text-xl font-bold text-brand-ink mb-3">
                    {c.values_title}
                  </h2>
                  <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                    {c.values_body}
                  </p>
                </div>
              </Reveal>
            )}
          </div>
        </section>
      )}

      <DonateCTA />
    </>
  );
}
