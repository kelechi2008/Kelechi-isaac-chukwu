import "./globals.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import PageEntrance from "../components/PageEntrance";

export const metadata = {
  title: "The Zipporah Foundation | Changing the World, One Teenager at A Time",
  description:
    "The Zipporah Youth Empowerment Initiative (TZYEI) protects and empowers vulnerable and disabled teenagers across Nigeria through outreach, skills training, and community partnerships.",
  openGraph: {
    title: "The Zipporah Foundation",
    description:
      "Changing the World, One Teenager at A Time. Transforming communities by empowering teenagers — one life, one story, one future at a time.",
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <PageEntrance />
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
