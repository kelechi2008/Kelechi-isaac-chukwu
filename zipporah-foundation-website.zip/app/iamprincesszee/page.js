"use client";
import { useEffect, useState } from "react";
import { getContent } from "../../lib/content";
import Reveal from "../../components/Reveal";
import DonateCTA from "../../components/DonateCTA";

const DEFAULTS = {
  eyebrow: "Meet the Founder",
  name: "",
  role: "Founder, The Zipporah Foundation",
  photo_url: "",
  bio: "",
  quote: "",
  social_label: "",
  social_url: "",
};

export default function FounderPage() {
  const [c, setC] = useState(DEFAULTS);

  useEffect(() => {
    getContent("founder", DEFAULTS).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28 grid md:grid-cols-12 gap-12 items-start">
        <div className="md:col-span-5">
          <Reveal>
            <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-gray-100 shadow-xl">
              {c.photo_url ? (
                <img
                  src={c.photo_url}
                  alt={c.name || "Founder"}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400 text-sm text-center px-6">
                  [Photo to be added in Admin]
                </div>
              )}
            </div>
          </Reveal>
        </div>
        <div className="md:col-span-7">
          <Reveal delay={60}>
            <p className="text-brand-orange font-semibold mb-4">{c.eyebrow}</p>
          </Reveal>
          <Reveal delay={120}>
            <h1 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink mb-3 leading-tight">
              {c.name || "[Founder name to be added in Admin]"}
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="text-brand-purple font-semibold mb-8">{c.role}</p>
          </Reveal>
          {c.quote && (
            <Reveal delay={200}>
              <blockquote className="border-l-4 border-brand-purple pl-6 text-lg text-brand-ink font-medium italic mb-8 max-w-xl">
                &ldquo;{c.quote}&rdquo;
              </blockquote>
            </Reveal>
          )}
          <Reveal delay={240}>
            <p className="text-gray-600 leading-relaxed whitespace-pre-line max-w-2xl mb-8">
              {c.bio || "[Founder's biography to be added in Admin]"}
            </p>
          </Reveal>
          {c.social_url && (
            <Reveal delay={280}>
              <a
                href={c.social_url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center rounded-full bg-brand-purple text-white font-semibold px-6 py-3 hover:bg-brand-purpleDark hover:-translate-y-0.5 transition-all"
              >
                {c.social_label || "Connect"}
              </a>
            </Reveal>
          )}
        </div>
      </section>

      <DonateCTA />
    </>
  );
}
