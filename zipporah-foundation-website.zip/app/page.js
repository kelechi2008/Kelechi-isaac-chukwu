import Hero from "../components/Hero";
import ImpactStats from "../components/ImpactStats";
import About from "../components/About";
import WhatWeDo from "../components/WhatWeDo";
import RecentUpdates from "../components/RecentUpdates";
import GetInvolved from "../components/GetInvolved";
import ImpactStories from "../components/ImpactStories";
import Partners from "../components/Partners";
import DonateCTA from "../components/DonateCTA";

export default function HomePage() {
  return (
    <>
      <Hero />
      <ImpactStats />
      <About />
      <WhatWeDo />
      <RecentUpdates />
      <GetInvolved />
      <ImpactStories />
      <Partners />
      <DonateCTA />
    </>
  );
}
