"use client";
import { useEffect, useState } from "react";
import { getContent } from "../../lib/content";
import Reveal from "../../components/Reveal";
import GetInvolved from "../../components/GetInvolved";
import DonateCTA from "../../components/DonateCTA";

const DEFAULTS = {
  eyebrow: "What we do",
  headline: "",
  intro_body: "",
  card1_title: "Our Outreaches",
  card1_body: "",
  card1_label: "See Projects..",
  card1_url: "/our-projects",
  card2_title: "Impact Stories",
  card2_body: "",
  card2_label: "Read More",
  card2_url: "/our-projects#impact-stories",
  card3_title: "Our Partners",
  card3_body: "",
  card3_label: "See Partners..",
  card3_url: "#partners",
};

export default function WhatWeDoPage() {
  const [c, setC] = useState(DEFAULTS);

  useEffect(() => {
    getContent("what_we_do", DEFAULTS).then(setC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const cards = [
    { title: c.card1_title, body: c.card1_body, label: c.card1_label, url: c.card1_url },
    { title: c.card2_title, body: c.card2_body, label: c.card2_label, url: c.card2_url },
    { title: c.card3_title, body: c.card3_body, label: c.card3_label, url: c.card3_url },
  ];

  return (
    <>
      <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28">
        <Reveal>
          <p className="text-brand-purple font-semibold mb-3 uppercase tracking-wide text-sm">
            {c.eyebrow}
          </p>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink mb-6 leading-tight max-w-3xl">
            {c.headline}
          </h1>
        </Reveal>
        {c.intro_body && (
          <Reveal delay={140}>
            <p className="text-gray-600 leading-relaxed whitespace-pre-line max-w-2xl mb-4">
              {c.intro_body}
            </p>
          </Reveal>
        )}
      </section>

      <section className="max-w-7xl mx-auto px-5 md:px-8 pb-20 md:pb-28">
        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((card, i) => (
            <Reveal key={i} delay={i * 120}>
              <div className="group bg-white rounded-3xl p-8 h-full border border-black/5 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all">
                <span className="text-brand-purple/30 font-heading text-sm">0{i + 1}</span>
                <h3 className="font-heading text-xl font-bold text-brand-ink mt-2 mb-3">
                  {card.title}
                </h3>
                <p className="text-gray-600 leading-relaxed mb-4 text-sm">{card.body}</p>
                <a
                  href={card.url}
                  className="inline-flex items-center gap-2 text-brand-purple font-semibold text-sm group-hover:gap-3 transition-all"
                >
                  {card.label} <span aria-hidden>→</span>
                </a>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <GetInvolved />
      <DonateCTA />
    </>
  );
}
