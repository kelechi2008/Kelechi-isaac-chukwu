"use client";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";
import { getContent, getRows } from "../../lib/content";

const DEFAULTS = {
  headline: "We would love to Hear from You",
  subheadline: "Please write or call us with your questions or comments.",
  address_label: "Address",
  address:
    "Suite 103, Holborn House, Plot 649, Frank Afegbua Crescent, Zone E Extension, Federal Capital Territory, Abuja.",
  contact_label: "Contact",
  phones: "+2347077777659, +2347077777905, +2347077777931",
  emails: "thezipporahproject@gmail.com, info@thezipporahfoundation.org",
};

// "+234..., +234..., +234..." -> ["+234...", "+234...", "+234..."]
function splitList(value) {
  return (value || "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

export default function ContactPage() {
  const [c, setC] = useState(DEFAULTS);
  const [socials, setSocials] = useState([]);
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [status, setStatus] = useState(null);

  useEffect(() => {
    getContent("contact", DEFAULTS).then(setC);
    getRows("social_links").then((rows) => setSocials(rows.filter((r) => r.is_visible)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const phones = splitList(c.phones);
  const emails = splitList(c.emails);

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      setStatus({ ok: false, msg: "Please fill in your name, email and message." });
      return;
    }
    setStatus({ ok: null, msg: "Sending..." });
    const { error } = await supabase.from("contact_messages").insert(form);
    if (error) {
      setStatus({ ok: false, msg: "Something went wrong. Please try again." });
    } else {
      setStatus({ ok: true, msg: "Message sent — thank you! We'll get back to you soon." });
      setForm({ name: "", email: "", phone: "", message: "" });
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28 grid md:grid-cols-2 gap-14">
      <div>
        <h1 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink mb-4">
          {c.headline}
        </h1>
        <p className="text-gray-600 leading-relaxed mb-10">{c.subheadline}</p>

        <div className="mb-8">
          <h2 className="font-heading font-bold text-brand-ink mb-2">{c.address_label}</h2>
          <p className="text-gray-600 leading-relaxed max-w-sm">{c.address}</p>
        </div>

        <div className="mb-10">
          <h2 className="font-heading font-bold text-brand-ink mb-2">{c.contact_label}</h2>
          <ul className="space-y-1.5 text-gray-600">
            {phones.length > 0 && (
              <li>
                {phones.map((p, i) => (
                  <span key={p}>
                    <a href={`tel:${p.replace(/\s+/g, "")}`} className="hover:text-brand-purple">
                      {p}
                    </a>
                    {i < phones.length - 1 && ", "}
                  </span>
                ))}
              </li>
            )}
            {emails.map((email) => (
              <li key={email}>
                <a href={`mailto:${email}`} className="hover:text-brand-purple">
                  {email}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex gap-3">
          {socials.map((s) => (
            <a
              key={s.id}
              href={s.url}
              target="_blank"
              rel="noreferrer"
              className="w-9 h-9 rounded-full bg-brand-ink text-white flex items-center justify-center text-xs font-semibold hover:bg-brand-purple"
            >
              {s.platform?.[0]?.toUpperCase()}
            </a>
          ))}
        </div>
      </div>

      <form onSubmit={submit} className="bg-white rounded-2xl shadow-sm border border-black/5 p-8 space-y-4 h-fit">
        <div>
          <label className="block text-sm font-medium text-brand-ink mb-1">Name</label>
          <input
            type="text"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-purple"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-brand-ink mb-1">Email</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-purple"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-brand-ink mb-1">Phone (optional)</label>
          <input
            type="tel"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-purple"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-brand-ink mb-1">Message</label>
          <textarea
            rows={5}
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            className="w-full rounded-lg border border-gray-300 px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-brand-purple"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-full bg-brand-purple text-white font-semibold py-3 hover:bg-brand-purpleDark transition-colors"
        >
          Send Message
        </button>
        {status && (
          <p className={`text-sm ${status.ok ? "text-green-600" : status.ok === false ? "text-red-600" : "text-gray-500"}`}>
            {status.msg}
          </p>
        )}
      </form>
    </section>
  );
}
