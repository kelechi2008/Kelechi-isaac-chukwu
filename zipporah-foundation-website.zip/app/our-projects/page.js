"use client";
import { useEffect, useState } from "react";
import { getRows } from "../../lib/content";
import ImpactStories from "../../components/ImpactStories";
import DonateCTA from "../../components/DonateCTA";

export default function ProjectsPage() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    getRows("projects").then((rows) => setProjects(rows.filter((r) => r.is_visible)));
  }, []);

  return (
    <>
      <section className="max-w-7xl mx-auto px-5 md:px-8 py-20 md:py-28">
        <p className="text-brand-purple font-semibold mb-3">Our Outreaches</p>
        <h1 className="font-heading text-3xl md:text-5xl font-extrabold text-brand-ink mb-6">
          Our Projects
        </h1>
        <p className="text-gray-600 max-w-2xl leading-relaxed mb-14">
          See how we&apos;re showing up for vulnerable teenagers across Nigeria with love, learning,
          and lasting support.
        </p>

        {projects.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-6">
            {projects.map((p) => (
              <a
                key={p.id}
                href={p.link_url}
                className="group rounded-2xl overflow-hidden bg-white border border-black/5 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="aspect-[4/3] bg-gray-100">
                  {p.image_url ? (
                    <img
                      src={p.image_url}
                      alt={p.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">
                      [Image to be added]
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="font-heading font-bold text-brand-ink mb-2">{p.title}</h3>
                  <p className="text-sm text-gray-600">{p.description}</p>
                </div>
              </a>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 italic">
            [Projects to be added from the Admin dashboard]
          </p>
        )}
      </section>
      <ImpactStories />
      <DonateCTA />
    </>
  );
}
