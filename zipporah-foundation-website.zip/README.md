# The Zipporah Foundation — Website

A modernized, fully editable website for The Zipporah Foundation, built with Next.js and Supabase.
Every piece of content — text, buttons, links, stats, stories, projects, partners, updates, social
links, and the donate button (Paystack) — is stored in Supabase and editable from `/admin`, with
no code changes needed.

## What's real vs. placeholder

All text, stats, testimonials, and links in this build were taken directly from the live
thezipporahfoundation.org site and its screenshots. Photos were **not** included in the file you
uploaded (the `_files` folder wasn't attached), so image slots are left as clearly marked
placeholders — upload the real photos through the admin dashboard once it's live, and they'll
appear immediately, no redeploy needed.

## 1. Create your Supabase project

1. Go to https://supabase.com → New Project.
2. Once it's created, go to **SQL Editor** → paste the entire contents of `supabase/schema.sql`
   → Run. This creates every table, security rule, and seeds it with the real content above.
3. Go to **Project Settings → API** and copy:
   - Project URL
   - `anon` public key

## 2. Create your admin login

1. In Supabase, go to **Authentication → Users → Add User**.
2. Enter your email and a password. This is what you'll use to log into `/admin`.
   (You can add more admin users the same way later.)

## 3. Configure the project

1. Copy `.env.local.example` to `.env.local`.
2. Fill in the two values from step 1:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=xxxxx
   ```

## 4. Run it locally

```bash
npm install
npm run dev
```

Visit http://localhost:3000 for the site, and http://localhost:3000/admin to log in.

## 5. Deploy

The easiest route is **Vercel** (free for this size of site):

1. Push this folder to a GitHub repo.
2. Go to https://vercel.com → New Project → import the repo.
3. Add the same two environment variables from `.env.local` in Vercel's project settings.
4. Deploy. You'll get a live URL, and you can attach your real domain
   (thezipporahfoundation.org) afterward in Vercel's Domains settings.

## Editing everything from /admin

Once logged in at `/admin`, the dashboard has tabs for:

- **Page Text** — hero, about, what-we-do cards, volunteer banner, donate section, contact info,
  footer — every heading, paragraph, and button label/URL on the site
- **Navigation** — add/remove/reorder nav links, including dropdown items
- **Stats** — the impact numbers (987+ Teenagers Impacted, etc.)
- **Impact Stories** — testimonials (Amina, David Pam) — add more or edit as real new stories come in
- **Projects** — the outreach projects shown on /our-projects
- **Updates** — the "Recent Updates" news cards
- **Partners** — the partner organization logos
- **Social Links** — Facebook, X, Instagram, TikTok, etc.
- **Messages** — anything submitted through the Contact Us form

Image fields take a direct image URL. To host your own images, use **Supabase Storage**:
Storage → `zipporah-media` bucket (already created by the schema) → upload a file → copy its
public URL → paste into the relevant image field in admin.

## About the Donate button

The donate button/section is wired to your real Paystack payment page
(`https://paystack.com/pay/donatezippo`) by default, and that URL is fully editable from
**Page Text → Donate Section** if it ever changes. This keeps setup simple and secure since no
Paystack secret keys are needed in the website itself. If you'd like an embedded in-page Paystack
checkout (rather than linking out to the Paystack page) as a future upgrade, that requires a small
server-side function to keep your Paystack secret key safe — happy to build that when you're ready.

## Tech stack

- Next.js 14 (App Router) + Tailwind CSS
- Supabase (Postgres database, Auth, Storage) — this is the CMS/backend
- Deployed on Vercel (or any Node host)
